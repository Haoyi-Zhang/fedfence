# FedFence

Target journal: ACM Transactions on Software Engineering and Methodology (TOSEM).

- `paper/main.tex`: current manuscript source, with included sections, figures and bibliography.
- `paper/FedFence_TOSEM.pdf`: single-column review manuscript; build instructions and data checks are in `paper/README.md`.
- `artifact/README.md`: repository entry point and reproduction instructions. The nested `artifact/artifact/` contains the original core library and is intentionally retained.

The current character-domain implementation covers Python string code points rather than a fixed finite character pool. Historical pre-character-domain records, where retained, are explicitly historical controls, not current verification results. See the manuscript and artifact instructions for the supplied-model, study-adapter and non-deployment limits. No additional execution or independent reproduction is implied by this package layout.

The finite-event library supports literal brackets, missing claims, and the empty observation basis for constant predicates. Reproduction instructions and execution records are indexed in `artifact/README.md`. Historical character-domain controls remain separate from the source-bound outputs. The manuscript's local-cost measurements are the recorded Linux measurements, not the Windows recheck timings.
