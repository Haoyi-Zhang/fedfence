# Bibliography scope audit

The bibliography contains **63 unique entries, all cited in the active manuscript**. The final consistency audit checks the equality of cited and defined key sets. No `\nocite{*}` is used to inflate the bibliography. The bibliography is not represented as 63 peer-reviewed research papers.

- frozen-public-source-record: 22 entries.
- official-tool-or-provider-documentation: 12 entries.
- research-publication: 22 entries.
- standard-or-specification: 7 entries.

`REFERENCE_AUDIT.csv` and `.json` retain each key, type, title, year, DOI/URL, primary checking source and claim boundary. Research identities were checked using primary publisher/proceedings, author-manuscript or author-bibliography sources. The ledger does not assert that every cited full text received an independent complete rereview. Bibliographic page fields are filled only where verified; a missing optional publisher/address/page field is not silently invented to eliminate BibTeX warnings.

## Frozen public records are a different evidence class

Public change and source-frontier references preserve the supplied commit hashes, titles and source locations. Dates described as frozen metadata are not claims of a fresh online visit. Correspondence to supplied local patch/excerpt/record hashes was checked by the artifact. Remote authenticity, repository-owner confirmation, actual variable assignments, and live deployment effects were not established. The manuscript attributes reported observations accordingly.

## Research and tool comparisons

The related-work section distinguishes policy verification (Margrave, Zelkova, Cedar), workflow taint analysis (ARGUS), IaC analysis (security-smell and configuration-verification work), provenance frameworks (in-toto, Sigstore, TUF, SLSA), and testing/verification foundations. No reference to a tool is converted into a claimed empirical baseline run. The paper expressly does not claim algorithmic superiority over these systems.

Standards and provider documentation explain supported constructs and the need to record an issuer profile. They do not establish that a 2026 live issuer is completely represented by the strict legacy model. The finite public-study domains are separately identified.

## Remaining formatting warnings

The checked build has no unresolved citation keys or undefined references. Some ACM BibTeX optional metadata warnings remain where publisher address or pagination was not verified. The primary identifiers and existing article/page information are preserved; this ledger does not label optional-field completeness as remotely verified. Authors can augment those fields from the publisher's own exported record without changing the source identity or the cited claim.

## Character-domain correction

The added `python-unicode` entry cites the official Python Unicode HOWTO for the selected code-point model. It is documentation, not a new empirical study. The support-preservation proof and its implementation boundary are stated in the manuscript; the external source does not prove the program correct.
