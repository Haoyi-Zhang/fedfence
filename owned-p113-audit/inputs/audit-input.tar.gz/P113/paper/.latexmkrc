# Prefer the ordinary BibTeX executable; some TeX distributions expose only
# bibtex.original or bibtex8. Do not replace the reference style or class.
for my $candidate ('bibtex', 'bibtex.original', 'bibtex8') {
    if (system("command -v $candidate >/dev/null 2>&1") == 0) {
        $bibtex = "$candidate %O %B";
        last;
    }
}
