"""Re-render numerical figures from the bundled fixed tables.

This renderer does not regenerate research measurements. Run with Python,
Matplotlib, NumPy and an available native LaTeX installation (including the
document's font packages and dvipng). PDF/SVG are vector exports; PNG is 600 dpi.
Output files are written to figures/rendered for inspection before replacement.
"""
from pathlib import Path
import csv, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
HERE=Path(__file__).resolve().parent
PROJECTS={'P113':{'paper':str(HERE.parent)}}
SPECS={'P113':[('local-costs', None, 'panels', {'width': 6.0, 'height': 2.7})]}

def read_table(path):
    text=path.read_text(encoding='utf-8-sig')
    lines=[s for s in text.splitlines() if s.strip() and not s.lstrip().startswith(('#','%'))]
    if ',' in lines[0]: return list(csv.DictReader(lines))
    headers=lines[0].split()
    return [dict(zip(headers,s.split(),strict=True)) for s in lines[1:]]

def num(s):
    if '/' in str(s):
        a,b=str(s).split('/'); return float(a)/float(b)
    return float(s)

def values(rows,k): return np.asarray([num(r[k]) for r in rows])

def style(ident):
    acm=ident in {'P010','P019','P081','P113'}
    preamble=r'\usepackage[T1]{fontenc}'
    preamble += r'\usepackage{libertine}\usepackage[libertine]{newtxmath}' if acm else r'\usepackage{mathptmx}'
    # IEEEtran uses Times text and Computer Modern mathematics; use times,
    # not mathptmx, so the mathematical alphabet stays unchanged.
    if not acm: preamble=r'\usepackage[T1]{fontenc}\usepackage{times}'
    plt.rcParams.update({'text.usetex':True,'text.latex.preamble':preamble,
      'font.family':'serif','font.serif':['Computer Modern Roman'],'font.size':9 if acm else 8,
      'axes.labelsize':9 if acm else 8,'xtick.labelsize':8.5 if acm else 8,
      'ytick.labelsize':8.5 if acm else 8,'legend.fontsize':8.5 if acm else 8,
      'axes.linewidth':0.6,'lines.linewidth':0.8,'lines.markersize':4,
      'pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':600,
      'axes.spines.top':False,'axes.spines.right':False})

def finish(fig,axes,out,name):
    fig.canvas.draw()
    out.mkdir(parents=True,exist_ok=True)
    fig.savefig(out/(name+'.pdf'),metadata={'Creator':'Matplotlib','Title':None})
    fig.savefig(out/(name+'.svg'))
    fig.savefig(out/(name+'.png'),dpi=600)
    plt.close(fig)

def plot(ident,name,table,kind,cfg):
    p=PROJECTS[ident]; paper=Path(p['paper']); out=HERE/'rendered'
    style(ident)
    fig=plt.figure(figsize=(cfg['width'],cfg['height']),layout='constrained')
    evidence=[]
    if kind=='panels':
        axes=fig.subplots(1,3,sharey=True)
        for ax,cat,label,marker,ls in zip(axes,['pass','loss','replay'],['(a) Passing review','(b) Positive loss','(c) Receipt replay'],['o','s','^'],['-','--',':']):
            path=paper/'generated'/f'scaling-{cat}.dat'; rows=read_table(path)
            x,y=values(rows,'n'),values(rows,'median')
            err=np.asarray([values(rows,'lower'),values(rows,'upper')])
            assert (err>=0).all()
            ax.errorbar(x,y,yerr=err,marker=marker,ls=ls,color='black',capsize=2,elinewidth=.6)
            ax.set_xscale('log',base=2); ax.set_xlim(.8,40); ax.set_ylim(0,.85)
            ax.set_xticks([1,2,4,8,16,32],labels=['1','2','4','8','16','32'])
            ax.set_yticks([0,.2,.4,.6,.8]); ax.grid(axis='y',alpha=.18,lw=.4)
            ax.text(.5,1.04,label,transform=ax.transAxes,ha='center',va='bottom',fontsize=8.5)
            evidence.append({'table':str(path),'x':x.tolist(),'y':y.tolist(),'errors':err.tolist()})
        axes[0].set_ylabel('Local elapsed seconds')
        fig.supxlabel('Required identities (also varied in the Allow list)',fontsize=9)
    else:
        ax=fig.add_subplot(); axes=[ax]
        path=paper/table; rows=read_table(path)
        if 'labels' in cfg:
            assert len(rows)==len(cfg['labels']), (ident,name,len(rows))
            x=np.arange(len(rows)); ax.set_xticks(x,labels=cfg['labels'])
        else:x=values(rows,cfg['x'])
        for n,ykey in enumerate(cfg['ys']):
            y=values(rows,ykey); label=cfg.get('legends',[None]*len(cfg['ys']))[n]
            ec={'table':str(path),'x':x.tolist(),'y':y.tolist(),'ykey':ykey}
            if kind=='bar':
                w=.72/len(cfg['ys']); xpos=x+(n-(len(cfg['ys'])-1)/2)*w
                bars=ax.bar(xpos,y,width=w,color=['.35','.68','#6495b8'][n%3],edgecolor='black',linewidth=.5,label=label)
                if cfg.get('values'):
                    ax.bar_label(bars,labels=[f'{v:g}' for v in y],padding=3,fontsize=8.5)
                if ident in {'P010','P019'} and name in {'baselines','reference-plot'}:
                    plt.setp(ax.get_xticklabels(),rotation=25,ha='right')
                ax.grid(axis='y',alpha=.2,lw=.4);ax.set_axisbelow(True)
            elif kind=='scatter': ax.scatter(x,y,s=14,facecolors='none',edgecolors='black',linewidths=.6,label=label)
            else:
                marker=['o','s','^'][n%3]; ls=['-','--',':'][n%3]
                if cfg.get('only_second') and n==1:ls='None'
                if kind=='error':
                    err=np.asarray([values(rows,k) for k in cfg['errors'][n]]);assert (err>=0).all()
                    ax.errorbar(x,y,yerr=err,color='black',marker=marker,ls=ls,capsize=2,elinewidth=.6,label=label)
                    ec['errors']=err.tolist()
                else:ax.plot(x,y,color='black',marker=None if cfg.get('boundary') else marker,markerfacecolor='white' if n else 'black',ls=ls,label=label)
                ax.grid(alpha=.2,lw=.4)
            evidence.append(ec)
        if cfg.get('diagonal'):ax.plot([1,1e6],[1,1e6],'--',color='.4',lw=.7,label=cfg['legends'][-1])
        if cfg.get('unit'):ax.axhline(1,color='.4',ls=':',lw=.8,label=cfg['legends'][-1])
        if cfg.get('boundary'):
            ax.plot([1.5,1.5],[36,45.5],':',color='.3',lw=.7)
            ax.text(1.45,39,r'$\rho=3/2$',ha='right',va='bottom',fontsize=8)
        if 'xlabel' in cfg:ax.set_xlabel(cfg['xlabel'])
        ax.set_ylabel(cfg['ylabel'])
        for xy in ('x','y'):
            if cfg.get(xy+'scale')=='log':getattr(ax,'set_'+xy+'scale')('log',base=cfg.get(xy+'base',10))
            if xy+'lim' in cfg:getattr(ax,'set_'+xy+'lim')(cfg[xy+'lim'])
            if xy+'ticks' in cfg:
                ticks=cfg[xy+'ticks'];getattr(ax,'set_'+xy+'ticks')(ticks,labels=[f'{t:g}' for t in ticks])
        if 'legends' in cfg:ax.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncol=1 if kind=='scatter' else min(3,len(cfg['legends'])),frameon=False,handlelength=2, columnspacing=.9)
    finish(fig,axes,out,name)
    return {'id':ident,'name':name,'output':str(out/(name+'.pdf')),'series':evidence,'science_executed':False}


if __name__=='__main__':
    for ident, charts in SPECS.items():
        for name,table,kind,cfg in charts:
            plot(ident,name,table,kind,cfg)
            print('Rendered',name)
