# FedFence - ACM TOSEM manuscript

`FedFence_TOSEM.pdf` is built from the `main.tex` and included sources in this directory. The manuscript uses the ACM review format on US Letter pages. Its nine editable vector figures use TikZ/PGFPlots, with accessibility descriptions; the local-cost plot reads the included generated data. No font files or image-generation service are needed to rebuild the figures.

## Build the paper

From this directory, with the supplied tables and plot data in place:

```sh
make
```

From the package root, `make -C paper` rebuilds the manuscript without rerunning experiments. Compilation requires `latexmk`, BibTeX, and the packages listed in `main.tex`. The recorded build uses the unmodified installed `acmart` v2.12 (2024-12-28), ACM-Reference-Format, and the publisher font families. No custom class, margin/font scaling, or length-padding commands are distributed.

The quantitative tables and macros are in `generated/`. Current semantic counts describe the separately retained nine-stage CPython 3.12.14 Linux run 37670050420, including 204 ordinary tests and 225 source-bound output files. Seven scalar methods and eight assembler guards are separate from those 204 tests. `generated/generation.json` records its actual receipt and run identity. The older 194-test record and ten-stage receipts are historical. The cost tables and plot retain the Python 3.13.5 Linux measurements, separately from the newer Linux and Windows records. A nine-stage scientific run does not include a paper build or PDF audit.

## Reproduce the included experiments

From the package root:

```sh
cd artifact
make reproduce
```

This executes the local evidence, regenerates quantitative tables, builds the paper, and audits the resulting package. It replaces generated outputs and timings; it is a separate operation from compiling the supplied paper.

The current native semantic counts can instead be regenerated without running scientific drivers:

```sh
python -B scripts/generate_tosem_tables.py --current-receipt tosem/results/native-science/_fresh-science/current-science-receipt.json --evidence-root tosem/results/native-science
```

Run that command from `artifact/`. It reads the retained source-bound receipt and rejects changed bindings or inconsistent counts. The default historical generation path refuses the older test count when used with the current source.

## Sources, measurements, and template

The bibliography contains research papers, standards, tool documentation, and attributed frozen public-source records. The local-cost plot uses medians and observed ranges from the supplied raw CSV; those ranges are not confidence intervals. Provenance and licences of third-party materials remain with their respective source records.

The optional `make template-current` retrieves the separately pinned official acmart v2.20 files. It is not part of offline reproduction, and the recorded earlier retrieval was unsuccessful. It must not be confused with the installed v2.12 build. The supplied `generated/build_environment.json` records an earlier build, rather than the source relationship of the present PDF.

`docs/TOSEM_SUBMISSION_NOTES.md` contains the selected submission-format guidance. The main source is a named-author review copy; publisher-assigned rights and publication metadata are not fabricated. The class footer is standard template text, not a record of actual submission.
